# Everloom Adapter: Documentation

When the task involves documentation:

- preserve canonical terminology;
- update references after structural changes;
- check required sections and obvious broken links;
- distinguish current instructions from deprecated notes;
- verify generated files can be reopened and read.
