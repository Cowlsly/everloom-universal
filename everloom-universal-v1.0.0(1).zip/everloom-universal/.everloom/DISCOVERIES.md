# Everloom Discoveries

Use this file for findings that materially affect later work.

Each entry should include:

- date/time if available
- source or provenance
- finding
- confidence / verification state
- impact on task plan
