# Everloom Universal

Everloom is a vendor-neutral durable work protocol for long, multi-step tasks across repositories, folders, research projects, documentation work, investigations, migrations, and other complex workflows.

Its purpose is simple: preserve verified progress across AI runs, prevent repeated rediscovery, and leave every project in a state another worker can resume immediately.

## Core idea

The project supplies the mission. Everloom supplies the durable execution loop:

1. Establish objective, state, constraints, dependencies, and output locations.
2. Maintain a task ledger with evidence-based status.
3. Execute the highest-value unblocked work.
4. Save useful output immediately.
5. Verify before marking complete.
6. Record failures and changed assumptions.
7. Checkpoint frequently.
8. Finish each run with a self-contained resume packet.

## Quick start

Copy this project into your repository, or copy only the `.everloom/` folder plus `EVERLOOM.md`.

Then edit:

- `.everloom/task.yml`

Give your AI this instruction:

> Read `EVERLOOM.md` and `.everloom/task.yml`. Follow Everloom strictly. Resume from `.everloom/RESUME.md` if it contains prior state. Continue working through the highest-value unblocked tasks until a stop condition is reached. Update the ledger, checkpoint, discoveries, and resume packet as work proceeds.

## Suggested invocation

```text
EVERLOOM <repository-or-folder> <task>
```

Examples:

```text
EVERLOOM ./ Finish the highest-priority unfinished implementation work.
```

```text
EVERLOOM Cowlsly/Twin-Shell Audit memory architecture, consolidate duplicate services, test changes, and document blockers.
```

## Portable state directory

```text
.everloom/
├── task.yml
├── LEDGER.md
├── CHECKPOINT.md
├── DISCOVERIES.md
├── RESUME.md
└── templates/
```

## Compatibility

Everloom is designed to be readable by any capable AI agent or assistant that can inspect and edit files. Tool availability differs between platforms, so workers must obey the permissions and capabilities of their current environment.

## Safety and permissions

Everloom never grants permissions by itself. Workers must not:

- bypass access controls,
- exfiltrate secrets,
- perform destructive actions without authorization,
- claim background execution they cannot actually perform,
- mark work complete without verification evidence.

## License

See `LICENSE`.
