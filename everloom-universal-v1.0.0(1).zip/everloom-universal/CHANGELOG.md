# Changelog

## 1.0.0 — 2026-09-14

- Initial vendor-neutral Everloom release.
- Durable task manifest, work ledger, checkpoint, discoveries, and resume packet.
- Verification and failure-recovery rules.
- Code, research, security, and documentation adapters.
- Universal cross-AI start prompt.
- JSON Schema for task manifests.
